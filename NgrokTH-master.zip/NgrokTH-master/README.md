# NgrokTH
Instalación Correcta De Ngrok En Termux
#
# INSTALACIÓN
#
chmod 711 ngrok.sh
#
./ngrok.sh
#
Escriba su authtoken de Ngrok y pulse Enter
#
# Created by: Informatic_in_Termux
